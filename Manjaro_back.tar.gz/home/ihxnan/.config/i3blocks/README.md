I got these scripts from https://github.com/miklhh/i3blocks-config , kudos to miklhh.

return {
    "MunifTanjim/nui.nvim"
}

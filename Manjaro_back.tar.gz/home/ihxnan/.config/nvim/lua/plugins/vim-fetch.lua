return {
  'wsdjeg/vim-fetch',
  vim.keymap.set("n", "<leader><CR>", "gF") }
